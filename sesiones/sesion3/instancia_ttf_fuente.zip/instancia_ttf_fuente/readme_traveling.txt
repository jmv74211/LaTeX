Para compilar el fichero con XeLaTeX sencillamente ejecutar desde la línea de órdenes de la terminal lo siguiente:

xelatex te_lapsang_souchongs.tex
